function init() {
  Survey.dxSurveyService.serviceUrl = "";

  var css = {
    root: "sv_main sv_frame sv_default_css"
  };

  var model = new Survey.Model(
{
  "showProgressBar": "top",
  "showQuestionNumbers": "off",
  "surveyPostId": "tamsurvey",
  "completedHtml": "<h3>Thank you for completing the survey.</h3><p>Results are being collated and will be distributed in approximately one week.</p>",
  "loadingHtml": "Loading Survey...",
  "pages": [
    {
      "name": "user_page",
      "elements": [
        {
          "type": "dropdown",
          "name": "location",
          "title": "Where are you based?",
          "isRequired": true,
          "choices": [
            "Denmark",
            "Poland"
          ]
        },
        {
          "type": "dropdown",
          "name": "management",
          "title": "Do you manage or lead a team?",
          "isRequired": true,
          "choices": [
            {
              "value": "Manager",
              "text": "I manage or lead a team"
            },
            {
              "value": "Non-Manager",
              "text": "I am a member of a team"
            }
          ]
        },
        {
          "type": "dropdown",
          "name": "role",
          "title": "Are you primarily in Development, or Operations?",
          "isRequired": true,
          "choices": [
            "Development",
            "Operations"
          ]
        }
      ]
    },
    {
      "name": "page_engagement",
      "title": "Engagement",
      "elements": [
        {
          "type": "matrixdropdown",
          "name": "engagement",
          "title": "Alignment of Personal Goals and Interests with Work:",
          "columns": [
            {
              "name": "rating",
              "title": "I agree with the following statements:",
              "isRequired": true,
              "minRateDescription": "Disagree",
              "maxRateDescription": "Agree",
              "cellType": "rating",
              "rateValues": [
                1,
                2,
                3,
                4,
                5
              ]
            }
          ],
          "rows": [
            "The strategic goals of the broader organization are clear",
            "It is clear what I should do to help the company meet its goals and objectives",
            "There is a clear link between your work and the company goals and objectives",
            "My team helps me to complete me work",
            "Management decisions are transparent and explained",
            "My manager is fully aware of my skills and abilities",
            "I have sufficient information to make correct decisions about my work",
            "I have a clear understanding of informal structures and processes at work",
            "When something unexpected comes up I usually know who to ask for help",
            "I feel valued in my role and feel trusted to do my work",
            "I have freedom to make mistakes and learn from them"
          ]
        }
      ]
    }
  ]
}
  );
  model.css = css;
  window.survey = model;
  model.render("surveyElement");

}

init();
