function getParams() {
  var url = window.location.href
    .slice(window.location.href.indexOf("?") + 1)
    .split("&");
  var result = {};
  url.forEach(function(item) {
    var param = item.split("=");
    result[param[0]] = param[1];
  });
  return result;
}

function init() {
  Survey.dxSurveyService.serviceUrl = "";

  var css = {
    root: "sv_main sv_frame sv_default_css"
  };

  var surveyId = decodeURI(getParams()["id"]);
  var model = new Survey.Model({
    "surveyPostId": 'tamsurvey',
     "completedHtml": "THIS<b>idafsd</b>the completed heml",
 "loadingHtml": "THIS<b>is the loading</b>HTml",
  "cookieName": "single_run_survey_cookie",
  "showProgressBar": "top",
  "showQuestionNumbers": "off",
  "pages": [
    {
      "name": "page_build_tools",
      "title": "Build Tools",
      "elements": [
        {
          "type": "matrixdropdown",
          "name": "build_tools",
          "title": "Opinion of any Build Tools used in the past 18-24 months:",
          "columns": [
            {
              "name": "rating",
              "title": "Should we be using it?",
              "isRequired": true,
              "minRateDescription": "Disagree",
              "maxRateDescription": "Agree",
              "cellType": "rating",
              "rateValues": [
                1,
                2,
                3,
                4,
                5
              ]
            }
          ],
          "rows": [
            "Gradle",
            "Maven",
            "Ant",
            "VSCode"
          ]
        }
      ]
    },
    {
      "name": "page_agile_frameworks_and_processes",
      "title": "Agile Frameworks And Processes",
      "elements": [
        {
          "type": "matrixdropdown",
          "name": "agile_frameworks_and_processes",
          "title": "Opinion of any Agile Frameworks or Processes used in the past 5 years:",
          "columns": [
            {
              "name": "rating",
              "title": "Should we be using it?",
              "isRequired": true,
              "minRateDescription": "Disagree",
              "maxRateDescription": "Agree",
              "cellType": "rating",
              "rateValues": [
                1,
                2,
                3,
                4,
                5
              ]
            }
          ],
          "rows": [
            "Kanban (loose planning, team choose tasks each iteration and update task state on board)",
            "Scrum (regular planning, constant comms within team via frequent short ceremonies)",
            "Scrumban (new planning sessions only after backlog items completed)"
          ]
        }
      ]
    }
  ]
}
);
  model.css = css;
  window.survey = model;
  model.render("surveyElement");

}

init();
