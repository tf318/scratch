Survey
    .StylesManager
    .applyTheme("default");

var json = {
 "showProgressBar": "bottom",
 "pages": [
  {
   "name": "pageBuildTools",
   "title": "Build Tools",  
   "elements": [
    {
     "type": "matrixdropdown",
     "name": "buildTools",
     "title": "Please give feedback on any tools you have used in the past 18-24 months:",
     "defaultValue": {
      "Gradle": { "more": "No opinion" },
      "Maven": { "more": "No opinion" },
      "Ant": { "more": "No opinion" }
     },
     "columns": [
      {
       "name": "purpose",
       "title": "Used in past 18 months?",
       "cellType": "checkbox",
       "choices": [ "Experiment", "Development", "Production" ]
      },
      {
       "name": "more",
       "title": "Should we be using it?",
       "cellType": "dropdown",
       "choices": [ "Yes - a lot more!", "Yes", "No opinion", "Limit use if possible", "Stop using it immediately" ]
      }
     ],
     "rows": [
      "Gradle",
      "Maven",
      "Ant"
     ]
    }
   ]
  }
 ]
};

window.survey = new Survey.Model(json);
survey
    .onComplete
    .add(function (result) {
        document
            .querySelector('#surveyResult')
            .innerHTML = "result: " + JSON.stringify(result.data);
    });

$("#surveyElement").Survey({model: survey});

