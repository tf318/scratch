{
 "showProgressBar": "bottom",
 "pages": [

  {
   "name": "pageBuildTools",
   "title": "Build Tools",  
   "elements": [
    {
     "type": "matrixdropdown",
     "name": "buildTools",
     "title": "Please give feedback on any Build Tools you have used in the past 18-24 months:",
     "defaultValue": {
      "Gradle": { "more": "No opinion" },
      "Maven": { "more": "No opinion" },
      "Ant": { "more": "No opinion" }
     },
     "columns": [
      {
       "name": "purpose",
       "title": "Used in past 18 months?",
       "cellType": "checkbox",
       "choices": [ "Experiment", "Development", "Production" ]
      },
      {
       "name": "more",
       "title": "Should we be using it?",
       "cellType": "dropdown",
       "choices": [ "Yes - a lot more!", "Yes", "No opinion", "Limit use if possible", "Stop using it immediately" ]
      }
     ],
     "rows": [
      "Gradle",
      "Maven",
      "Ant"
     ]
    }
   ]
  },

    {
   "name": "pageIDEs",
   "title": "Development Environments",  
   "elements": [
    {
     "type": "matrixdropdown",
     "name": "ides",
     "title": "Please give feedback on any Development Environments you have used in the past 18-24 months:",
     "defaultValue": {
      "IntelliJ IDEA": { "more": "No opinion" },
      "Eclipse": { "more": "No opinion" },
      "VSCode": { "more": "No opinion" }
     },
     "columns": [
      {
       "name": "purpose",
       "title": "Used in past 18 months?",
       "cellType": "checkbox",
       "choices": [ "Experiment", "Development", "Production" ]
      },
      {
       "name": "more",
       "title": "Should we be using it?",
       "cellType": "dropdown",
       "choices": [ "Yes - a lot more!", "Yes", "No opinion", "Limit use if possible", "Stop using it immediately" ]
      }
     ],
     "rows": [
      "IntelliJ IDEA",
      "Eclipse",
      "VSCode"
     ]
    }
   ]
  }
  

 ]
}