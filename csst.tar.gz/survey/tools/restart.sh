#!/bin/bash
cd ../surveyjs-php-master/docker/
docker-compose down
docker-compose up &

