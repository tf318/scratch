#!/bin/bash

. ./functions.sh

cd definitions

generate_json () {

	echo '{'
	echo '"showProgressBar": "top",'
	echo '"showQuestionNumbers": "off",'
	echo '"surveyPostId": "tamsurvey",'
	echo '"completedHtml": "<h3>Thank you for completing the survey.</h3><p>Results are being collated and will be distributed in approximately one week.</p>",'
	echo '"loadingHtml": "Loading Survey...",'
#	echo '"cookieName": "single_run_survey_cookie",'
	echo '"pages": ['

cat << ENDPAGE1
  {
   "name": "user_page",
   "elements": [
    {
     "type": "dropdown",
     "name": "location",
     "title": "Where are you based?",
     "isRequired": true,
     "choices": [
      "Denmark",
      "Poland"
     ]
    },
    {
     "type": "dropdown",
     "name": "management",
     "title": "Do you manage or lead a team?",
     "isRequired": true,
     "choices": [
      {
       "value": "Manager",
       "text": "I manage or lead a team"
      },
      {
       "value": "Non-Manager",
       "text": "I am a member of a team"
      }
     ]
    },
    {
     "type": "dropdown",
     "name": "role",
     "title": "Are you primarily in Development, or Operations?",
     "isRequired": true,
     "choices": [
      "Development",
      "Operations"
     ]
    }
   ]
  }
ENDPAGE1

#	start_page_loop=true

	cat topics.order | sed -e 's/ /_/g' | while read topic_name topic_description rating_question
	do
		topic_title=$(print_topic $topic_name)
		topic_description=$(replace_underscores $topic_description)
		rating_question=$(replace_underscores $rating_question)

#	 	if [ $start_page_loop == false ]; then echo "," ; fi ; start_page_loop=false
echo ","
	 	echo '{'
	 	echo "'name':'$(print_page_name $topic_name)',"
	 	echo "'title':'$topic_title',"
	 	echo "'elements': [{"
     	echo "'type': 'matrixdropdown',"
     	echo "'name': '$topic_name',"
     	echo "'title': '$topic_description:',"

     	echo "'columns': ["

 		echo "{"
 		echo "'name':'rating',"
 		echo "'title':'$rating_question',"
 		echo "'isRequired': true,"
 		echo "'minRateDescription':'Disagree',"
 		echo "'maxRateDescription':'Agree',"
 		echo "'cellType':'rating',"
 		echo "'rateValues':[ 1, 2, 3, 4, 5 ]"
 		echo "}"

 		echo "],"

 		echo "'rows':["
 		comma_separate $topic_name.list
 		echo "]"

	 	echo '}]'
	 	echo '}'

	done

	echo ']'
	echo '}' 

}

JSFILE=../../surveyjs-php-master/tamsurvey.js

cat > $JSFILE << ENDHEADER
function init() {
  Survey.dxSurveyService.serviceUrl = "";

  var css = {
    root: "sv_main sv_frame sv_default_css"
  };

  var model = new Survey.Model(
ENDHEADER

generate_json | tr "'" '"' | jq '.' >> $JSFILE

cat >> $JSFILE << ENDFOOTER
  );
  model.css = css;
  window.survey = model;
  model.render("surveyElement");

}

init();
ENDFOOTER
