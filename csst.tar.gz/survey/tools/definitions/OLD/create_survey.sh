#!/bin/bash

. ./functions.sh

cd definitions

generate_json () {

	echo '{'
	echo '"showProgressBar": "top",'
	echo '"showQuestionNumbers": "off",'

	echo '"pages": ['

	start_page_loop=true

	cat topics.order | while read topic_name topic_description
	do
		topic_title=$(print_topic $topic_name)
		topic_description=$(replace_underscores $topic_description)

	 	if [ $start_page_loop == false ]; then echo "," ; fi ; start_page_loop=false

	 	echo '{'
	 	echo "'name':'$(print_page_name $topic_name)',"
	 	echo "'title':'$topic_title',"
	 	echo "'elements': [{"
     	echo "'type': 'matrixdropdown',"
     	echo "'name': '$topic_name',"
     	echo "'title': '$topic_description:',"

		#defaultRating=$(grep '\*' $topic_name.ratings | sed -e 's/\*//'| awk -F\| '{print $1}' | sed -e 's/\*//')
		#defaultRating=$(grep '\*' $topic_name.ratings | sed -e 's/\*//'| awk -F\| '{print $2}')
# 		echo "'defaultValue': {"	
# 		start_dr_loop=true	
#		list_contents $topic_name.list | while read listItem
#		do
#		 	if [ $start_dr_loop == false ]; then echo "," ; fi ; start_dr_loop=false
#			#echo "'$listItem': { 'rating':$defaultRating}"
#			echo "'$listItem': { 'rating':'$defaultRating'}"
#		done
#		echo "},"


     	echo "'columns': ["

     	if [ -s $topic_name.envs.IGNORE ]; then
     		echo "{"
     		echo "'name':'environment',"
     		echo "'title':'$(description $topic_name.envs)',"
     		echo "'cellType':'checkbox',"
     		echo "'choices':["
     		comma_separate $topic_name.envs
     		echo "]"
     		echo "},"
     	fi

 		echo "{"
 		echo "'name':'rating',"
 		echo "'title':'Should we be using it?',"
 		echo "'isRequired': true,"
 		echo "'minRateDescription':'Disagree',"
 		echo "'maxRateDescription':'Agree',"
 		echo "'cellType':'rating',"
 		echo "'rateValues':["
 		start_rating_loop=true	
 		#cat $topic_name.ratings | while read rating_pair
 		cat topic.ratings | while read rating_pair
 		do
 			export value=$(echo $rating_pair | awk -F\| '{print $1}' | sed -e 's/\*//')
 			export text=$(echo $rating_pair | awk -F\|  '{print $2}')
# 		 	if [ $start_rating_loop == false ]; then echo "," ; fi ; start_rating_loop=false			
# 			echo "{"
# 			#echo "'value': $value,"
# 			echo "'value': '$text',"
# 			echo "'text': '$text'"
# 			echo "}"

#echo "'$text'"

 		done
echo "1,2,3,4,5"
 		#comma_separate $topic_name.ratings
 		echo "]"
 		echo "}"

 		echo "],"

 		echo "'rows':["
 		comma_separate $topic_name.list
 		echo "]"



	 	echo '}]'
	 	echo '}'


	done

	echo ']'
	echo '}' 

}

generate_json | tr "'" '"' | jq '.'
