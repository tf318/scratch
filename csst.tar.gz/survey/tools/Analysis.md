---
title: "Core Services IT Survey Results"
author:
- name: Tam Freestone Bayes
  affiliation: Copenhagen
output: 
  rmarkdown::pdf_document:
    toc: true
    number_section: yes
    citation_package: natbib
    keep_tex: true
    fig_caption: yes
    latex_engine: pdflatex
    template: /Users/tam/Development/survey/tools/templates/latex-ms.tex
header-includes:
  - \hypersetup{colorlinks=true, linkcolor=blue}    
abstract: "This report is an overview of several Core Services IT teams' perceptions of multiple technologies, toolsets, methodologies, and knowledge sharing practices. Its purpose is to identify the elements which team members feel work well (and those which do not). The analysis highlights elements for which inter-team adoption (or rejection) may be warranted in the near-term."
keywords: "software development, devops, Java, agile, toolsets, IDEs, methodologies, best practices"
date: "March 11, 2018"
geometry: margin=1in
fontfamily: charter
fontsize: 11pt
# spacing: double
bibliography: ./master.bib
biblio-style: apsr
endnote: no
#fig_height: 3 
#fig_width: 6 
fig.align: center
fig_caption: yes
#out.width: '.85\\linewidth'
---










# Executive Summary

To gain a clearer view of which **technologies**, **metholodologies**, and **knowledge sharing practices** are perceived as most effectual within the Core Services IT organisation, an invitation to participate in a survey was extended to all of its development and operations staff. Invitees were advised the survey would take 10-15 minutes to complete, and were given 48 hours to respond. 

A total of 8 participants completed the survey.

Strongly **positive feedback** was given for many technologies and processes, including: 
Gradle, Maven.

**Negatively viewed** technologies and processes include:
VSCode, Ant.

It is recommended that teams not currently making use of positively viewed elements are encouraged to do so. It is further recommended that teams employing negatively viewed elements should examine carefully their current return on investment, and potentially aim to phase out their future use.
\newpage



# Build Tools 
Opinion of any Build Tools Used in the Past 18-24 Months *- should we be using it?*

![plot of chunk reports1](figure/reports1-1.png)



# Agile Frameworks and Processes 
Opinion of any Agile Frameworks or Processes Used in the Past 5 Years *- should we be using it?*

![plot of chunk reports1](figure/reports1-2.png)

To aid participants in the survey, the following brief descriptions for the *Agile Frameworks and Processes* were provided:
\begin{table}[ht]
\centering
\begin{tabular}{ll}
  \hline
Item & Brief Description \\ 
  \hline
Kanban & loose planning, team choose tasks each iteration and update task state on board \\ 
  Scrum & regular planning, constant comms within team via frequent short ceremonies \\ 
  Scrumban & new planning sessions only after backlog items completed \\ 
   \hline
\end{tabular}
\caption{Brief descriptions of the Agile Frameworks and Processes in the survey.} 
\end{table}
