#!/bin/bash

. ./functions.sh

cd definitions

cat topics.order | sed -e 's/ /_/g' | while read topic_name topic_description rating_question
do
	topic_title=$(print_topic $topic_name)
	topic_description=$(replace_underscores $topic_description)

	echo "========================================================"
	echo $topic_title
	echo "========================================================"
	echo
	echo $topic_description
	echo

	rating_question=$(replace_underscores $rating_question)
	echo "$rating_question (rating from strongly disagree [1] to strongly agree [5]):"
	echo
	list_contents $topic_name.list | while read elem
	do
		echo " * $elem"
	done
	echo
	echo
done
