require(tools);
require(likert);
require(ggplot2);
require(xtable);

library(gridExtra)
library(grid)

setwd('/Users/tam/Development/survey/tools/');

as_title <- function(string_or_id) {
  return(toTitleCase(gsub("_", " ", string_or_id)));
}

# Load data:

headings <- read.table('./results/header.txt', sep="\t", header=FALSE);
headings$V4 <- toTitleCase(gsub("_", " ", headings$V1));
headings$V5 <- toTitleCase(gsub("\\(.*", "", headings$V2))


all_answers <- read.table('./results/all_answers.txt', header=FALSE);
names(all_answers) <- headings$V5;

# Recode each rating factor and explicitly set the levels in order:
possible_ratings <- c(
  "Strongly Disagree", 
  "Disagree",
  "No Opinion",
  "Agree",
  "Strongly Agree"
  );
lapply(seq_along(possible_ratings), function(idx) {
  all_answers[all_answers==idx] <<- possible_ratings[idx];
});
myLevels <- factor(possible_ratings, levels=possible_ratings)
for(i in seq_along(all_answers)) {
  all_answers[, i] <- factor(all_answers[, i], levels=myLevels)
}



topics <- read.table('./definitions/topics.order', header=FALSE, sep="\t");


# Useful functions:

get_topic_descriptors <- function(topic) {
  defs <- trimws(readLines(paste0('./definitions/', topic[1], '.list')));
  terms <- gsub(" \\(.*", "", defs)
  descriptions <- gsub("(.*?) \\((.*)\\)", "\\2", defs)
  descriptions[terms==descriptions] = ""
  df <- data.frame(terms, descriptions)
  names(df) <- c("Item", "Brief Description")
  return(xtable(df, paste("Brief descriptions of the", as_title(topic[1]), "in the survey.")));
}


get_likert <- function(topic) {
  staff_ratings <- all_answers[, which(headings$V1 == topic[1] & headings$V3 == "Rating")];
  return(likert(staff_ratings));
}

get_topic_plot <- function(topic, base_size=13, text_size=12) {
  
  plot.title = as_title(topic[1])
  plot.subtitle = paste(as_title(topic[2]), " - should we be using it?")
  
  return(
    likert.bar.plot(
      get_likert(topic), 
      positive.order=TRUE, 
      centered=TRUE, 
      order=TRUE, 
      plot.percent.neutral=FALSE,
      box.ratio=10
    ) + 
      theme_minimal(base_size=base_size) +
      theme(axis.text=element_text(size=text_size)) #+
    #labs(caption=paste("\\label{fig:",topic[1],"}","Partipant responses to", plot.title, "section"))  
    #labs(title = plot.title, subtitle = plot.subtitle) 
  )      
  
}

show_description_table_if_relevant <- function(topic) {
  table <- get_topic_descriptors(topic);
  if (!all(table[2]=="")) {
    cat(
      'To aid participants in the survey, ',
      'the following brief descriptions for the *', 
      as_title(topic[1]), 
      '* were provided:',
      '\n', sep=''
    );
    print(table, comment=FALSE, include.rownames=FALSE)
  }
  cat('\n')
};


# test
summary(get_likert('build_tools'))

ignore_result <- apply(topics, function(topic) {
  cat('\n#', as_title(topic[1]), '\n')
  cat(as_title(topic[2]), ' *', '- should we be using it?', '*\n\n', sep='')
  show(get_topic_plot(topic, base_size=10, text_size=10))
  cat('\n\n')
  #show_description_table_if_relevant(topic);
}, MARGIN=1);
