#!/bin/bash

# extract latest data from database and write to tab delimited file
./export.sh

# run R program and generate markdown
R -e knitr::knit2pdf"('~/Development/survey/tools/Analysis.Rmd', output = '~/Development/survey/tools/Analysis.utf8.md')"

# convert md file to pdf
/Applications/RStudio.app/Contents/MacOS/pandoc/pandoc +RTS -K512m -RTS Analysis.utf8.md --to latex --from markdown+autolink_bare_uris+ascii_identifiers+tex_math_single_backslash --output Analysis.tex --table-of-contents --toc-depth 2 --template /Users/tam/Development/survey/tools/templates/latex-ms.tex --number-sections --highlight-style tango --latex-engine pdflatex --natbib 

