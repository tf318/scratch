#!/bin/bash

. ./functions.sh

cd definitions


rm -rf ../results
mkdir -p ../results

#
# Build header information
#

cat topics.order | while read topic_name topic_description
do
	title=$(print_topic $topic_name)
	title=$topic_name
	list_contents $topic_name.list | while read listItem
	do
     	if [ -s $topic_name.envs.IGNORE ]; then
     		list_contents $topic_name.envs | while read environment
     		do
     				echo "$title	$listItem	Environment: $environment" >> ../results/header.txt
     		done
     	fi
     	echo  "$title	$listItem	Rating" >> ../results/header.txt
	done
done




# Query database and write out results for each user

echo 'psql -U postgres -d surveyjs -c "SELECT json FROM results"' | docker exec -i docker_dbsrv_1 bash | 
tail +3 | sed '$d' | sed '$d' | while read record
do
	#echo $record | jq '.'

	rm -f /tmp/survey_user_answers

	cat topics.order | while read topic_name topic_description
	do
		title=$(print_topic $topic_name)
		list_contents $topic_name.list | while read listItem
		do
	     	if [ -s $topic_name.envs.IGNORE ]; then
	     		list_contents $topic_name.envs | while read environment
	     		do
	     			env_checkbox=$(echo $record | jq ".$topic_name[\"$listItem\"].environment | contains([\"$environment\"])?")
	     			if [[ -z ${env_checkbox} ]]; then
	     				echo "false" >> /tmp/survey_user_answers
	     			else
	     				echo "$env_checkbox" >> /tmp/survey_user_answers
	     			fi
	     		done
	     	fi
			#echo "$title | $listItem"
			rating=$(echo $record | jq ".$topic_name[\"$listItem\"].rating")
			echo $rating >> /tmp/survey_user_answers
		done
	done

	generate_report_line /tmp/survey_user_answers >> ../results/all_answers.txt

done


