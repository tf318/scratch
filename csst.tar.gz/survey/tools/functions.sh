# Utility functions

print_page_name () {
	echo page_$1
}

print_topic () {
	# converts a string to upper case initial letters and replaces underscored
	# with spaces. For example, converts a string such as:
	#   this_is_a_test
	# to
	#   This Is A Test
	echo $1 | sed -e 's/_/ /g' | 
		awk '{for(i=1;i<=NF;i++){ $i=toupper(substr($i,1,1)) substr($i,2) }}1'
}

comma_separate () {
	# list all items in a file, and return as comma separated list.
	# note that this function will also wrap each item in double quotes ("")
	list_contents $1 | grep -v "^\#" | sed -e 's/\*//' | sed -e 's/\(.*\)/"\1"/' | paste -sd "," -
}

generate_report_line () {
	# list all items in a file, and return as tab separated list, with true and false converted to T/F
	list_contents $1 | sed -e 's/^false$/F/' | sed -e 's/^true$/T/' | grep -v "^\#" | sed -e 's/\*//' | paste -sd "	" -
}

tab_separate_quotes () {
	# list all items in a file, and return as comma separated list.
	# note that this function will also wrap each item in double quotes ("")
	list_contents $1 | grep -v "^\#" | sed -e 's/\*//' | sed -e 's/\(.*\)/"\1"/' | paste -sd "	" -
}

description () {
	# look for a line starting with #, and return it without the #
	cat $1 | grep "^\#" | sed -e 's/\#//' 
}

replace_underscores () {
	# replace all instances of "_" with " " in supplied value
	echo $1 | sed -e 's/_/ /g'
}

list_contents () {
	# trim leading and trailing spaces of each line in file
	cat $1 | awk -F\t '{print $1}' | grep -v '^#' | sed 's/ *$//' | sed 's/^ *//' 
}
